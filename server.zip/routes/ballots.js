const express = require('express')
const router = express.Router()
const ballotController = require('../controllers/BallotController')

router.get('/', (req, res, next) => {
    next();
}, ballotController.find);

router.get('/vuosi/:vuosi', (req, res, next) => {
    next();
}, ballotController.findForYear);

router.get('/vuosi/:year/kuukausi/:month', (req, res, next) => {
    next();
}, ballotController.findForMonth);

router.get('/:id', (req, res, next) => {
    next();
}, ballotController.findOne);

router.get('/:aanestysId/aanestysEdustajas', (req, res, next) => {
    next();
}, ballotController.findAanestysEdustajas);

module.exports = router;