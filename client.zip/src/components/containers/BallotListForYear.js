import React, { useEffect } from "react";
import { connect } from 'react-redux';

import AdvancedGridList from "./AdvancedGridList";
import { ballotsFetchData } from '../../actions/ballots';

const BallotListForYear = (props) => { 
    const getBallotVaskiLink = (aanestysValtiopaivaasia) => {
        // HE 36/2019
        const splittedBySpace = aanestysValtiopaivaasia.split(" ");
        const splittedBySlash = splittedBySpace[1].split("/");

        return 'https://www.eduskunta.fi/FI/vaski/KasittelytiedotValtiopaivaasia/Sivut/'
            + splittedBySpace[0]
            + "_"
            + splittedBySlash[0]
            + "+"
            + splittedBySlash[1]
            + ".aspx";
    }

    useEffect(() => {
        props.fetchData(`http://localhost:5001/ballots/vuosi/${props.match.params.year}`);
    }, []);

    if (props.ballots.length === 0) {
        if (!props.isLoading) {
            return <div>no ballots for year {props.match.params.year}...</div>
        }
        return <div>loading...</div>;
    }

    
    return (
        <AdvancedGridList ballots={props.ballots} year={props.match.params.year} />
    );
}

const mapStateToProps = (state) => {
    return {
        ballots: state.ballots,
        hasErrored: state.ballotsHasErrored,
        isLoading: state.ballotsIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url) => dispatch(ballotsFetchData(url))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BallotListForYear);
