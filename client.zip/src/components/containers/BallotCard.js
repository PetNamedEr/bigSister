import React, { useState, useEffect } from "react";
import { connect } from 'react-redux';
import BallotDetailPartyList from "./BallotDetailPartyList";
import BallotDetailVotesDistribution from "./BallotDetailVotesDistribution";
import { ballotsFetchData } from '../../actions/ballots';
import CustomPieChart from "./CustomPieChart";
import {green, red, blueGrey, brown} from '@material-ui/core/colors';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
    item: {
        border: 'solid 1px',
    },
    root: {
        backgroundColor: 'gray',
        textAlign: 'center',
        width: '100%',
        overflowX: 'hidden'
    },
  });

const BallotCard = (props) => {
    const getBallotVaskiLink = (aanestysValtiopaivaasia) => {
        // HE 36/2019
        const splittedBySpace = aanestysValtiopaivaasia.split(" ");
        const splittedBySlash = splittedBySpace[1].split("/");

        return 'https://www.eduskunta.fi/FI/vaski/KasittelytiedotValtiopaivaasia/Sivut/'
            + splittedBySpace[0]
            + "_"
            + splittedBySlash[0]
            + "+"
            + splittedBySlash[1]
            + ".aspx";
    }

    const getPartyList = () => {
        return [
            {
                name: 'kd',
                bgColor: 'navy',
                txtColor: 'white',
            },
            {
                name: 'kesk',
                bgColor: 'gold',
                txtColor: 'white',
            },
            {
                name: 'kok',
                bgColor: 'blue',
                txtColor: 'white',
            },
            {
                name: 'liik',
                bgColor: 'deeppink',
                txtColor: 'white',
            },
            {
                name: 'ps',
                bgColor: 'black',
                txtColor: 'white',
            },
            {
                name: 'r',
                bgColor: 'yellow',
                txtColor: 'black',
            },
            {
                name: 'sd',
                bgColor: 'red',
                txtColor: 'white',
            },
            {
                name: 'vas',
                bgColor: 'darkred',
                txtColor: 'white',
            },
            {
                name: 'vihr',
                bgColor: 'limegreen',
                txtColor: 'white',
            },
        ];
    };

    const getPieChartData = () => {
        if (props.ballots.length > 0) {
            return [
                {
                    name: 'yes',
                    value: props.ballots[0].aanestysTulosJaa,
                },
                {
                    name: 'no',
                    value: props.ballots[0].aanestysTulosEi,
                },
                {
                    name: 'empty',
                    value: props.ballots[0].aanestysTulosTyhjia,
                },
                {
                    name: 'away',
                    value: props.ballots[0].aanestysTulosPoissa,
                },
            ];
        }
    };

    useEffect(() => {
        props.fetchData(`http://localhost:5001/ballots/${props.match.params.id}`);
    }, []);

    const partyList = getPartyList();
    const pieChartData = getPieChartData();
    const colors = [green[500], red[500], blueGrey[500], brown[500]];
    const classes = useStyles();

    return(
        (props.ballots.length !== 1)
            ? <div>loading...</div>
            : (
                <div className={classes.root}>
                    {!props.isLoading ? (
                        <>
                        <br />
                        <br />
                        <BallotDetailPartyList partyList={partyList} />
                        <BallotDetailVotesDistribution partyList={partyList} aanestysId={props.ballots[0].aanestysId} />
                            <h1>
                                {props.ballots[0].kohtaOtsikko}
                            </h1>
                            <br />
                            <CustomPieChart justify="center" pieChartData={pieChartData} canvasWidth={400} canvasHeight={400} colors={colors} />
                            <br />
                            <h2>
                                {props.ballots[0].aanestysOtsikko}
                            </h2>
                            <br />
                            <a
                                href={getBallotVaskiLink(props.ballots[0].aanestysValtiopaivaasia)}
                                style={{color: 'purple'}}><h2>More information on parliament site</h2></a>
                            <br />
                            <br />
                        </>)
                        : (
                        <></>
                    )}
                </div>
            )
    );
}

const mapStateToProps = (state) => {
    return {
        ballots: state.ballots,
        hasErrored: state.ballotsHasErrored,
        isLoading: state.ballotsIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url) => dispatch(ballotsFetchData(url))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BallotCard);
