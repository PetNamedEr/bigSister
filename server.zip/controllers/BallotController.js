const db = require('../db.js');
const xssFilters = require('xss-filters');

find = (req, res, next) => (
  db.makeResQuery("SELECT * FROM bigsister_aanestys", req, res)
);

findForMonth = (req, res, next) => (
  db.makeResQuery(`SELECT * FROM bigsister_aanestys WHERE aanestysAlkuaika BETWEEN '${xssFilters.inHTMLData(req.params.year)}-${xssFilters.inHTMLData(req.params.month)}-01' AND '${xssFilters.inHTMLData(req.params.year)}-${xssFilters.inHTMLData(req.params.month)}-31'`, req, res)
);

findForYear = (req, res, next) => (
  db.makeResQuery(`SELECT * FROM bigsister_aanestys WHERE vuosi = ${xssFilters.inHTMLData(req.params.vuosi)}`, req, res)
);

findOne = (req, res, next)  => 
  (db.makeResQuery(`SELECT * FROM bigsister_aanestys WHERE aanestysId = ${xssFilters.inHTMLData(req.params.id)}`, req, res)
);

findAanestysEdustajas = (req, res, next)  => 
(db.makeResQuery(`SELECT * FROM bigsister_aanestysEdustaja WHERE aanestysId = ${xssFilters.inHTMLData(req.params.aanestysId)}`, req, res)
);

module.exports = {
  find,
  findAanestysEdustajas,
  findForMonth,
  findForYear,
  findOne,
}