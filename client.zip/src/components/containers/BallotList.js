import React, { useEffect } from "react";
import { connect } from 'react-redux';
import { CircularProgress } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';

import AdvancedGridList from "./AdvancedGridList";
import { ballotsFetchData } from '../../actions/ballots';

const useStyles = makeStyles({
    root: {
        backgroundColor: 'gray',
        textAlign: 'center',
        width: '100%',
        height: '100%',
    },
  });

const BallotList = (props) => {
    useEffect(() => {
        props.fetchData('http://localhost:5001/ballots');
    }, []);

    const classes = useStyles();

    return (
        <div className={classes.root}>
            {(props.ballots.length === 0)
                ? <CircularProgress />
                : <AdvancedGridList ballots={props.ballots} />}
        </div>
    );
}

const mapStateToProps = (state) => {
    return {
        ballots: state.ballots,
        hasErrored: state.ballotsHasErrored,
        isLoading: state.ballotsIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url) => dispatch(ballotsFetchData(url))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BallotList);
