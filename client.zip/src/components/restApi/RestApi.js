import $ from 'jquery'; 

export default class RestApi {
    get(url) {
        return $.ajax({
            type: "GET",
            url: url,
        });
    }
}