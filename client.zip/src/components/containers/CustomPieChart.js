import React, {useRef, useEffect} from 'react';
import Box from '@material-ui/core/Box';

function CustomPieChart(props) {
	const canvasRef = useRef(null);
    
    const colors = props.colors;
    const pieChartData = props.pieChartData;

    const drawPieChart = () => {
        let ctx = canvasRef.current.getContext("2d");
		let w = ctx.canvas.width;
		let h = ctx.canvas.height;
		ctx.clearRect(0, 0, w, h);
        let total = 0;

		for (let k in pieChartData) {
			total += pieChartData[k].value;
		}
		ctx.save();
		ctx.translate(w/2, h/2);
		let radius = Math.min(w, h) * 0.4;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.font = 10 + "pt sans-serif";
		let startAngle = 0;
		for (let k in pieChartData) {
            if (pieChartData[k].value !== 0) {
                let angle = Math.PI*2/total*pieChartData[k].value;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.arc(0, 0, radius, startAngle, startAngle+angle);
                ctx.fillStyle = colors[(0+k)%colors.length];
                ctx.fill();
                ctx.stroke();
                ctx.fillStyle = "black";
                startAngle += angle;    
            }
		}
		startAngle = 0;
		for (let k in pieChartData) {
            if (pieChartData[k].value !== 0) {
                let angle = Math.PI*2/total*pieChartData[k].value;
                ctx.fillText(pieChartData[k].name, Math.cos(startAngle+angle/2)*radius/4*3, Math.sin(startAngle+angle/2)*radius/4*3);
                startAngle += angle;
            }
		}
		ctx.restore();
    };
	
	useEffect(() => {
		drawPieChart();
    });

	return (
        <>
            <Box>
                <canvas width={props.canvasWidth} height={props.canvasHeight} ref={canvasRef} style={{ cursor: 'context-menu' }} />
            </Box>
        </>
	);
}

export default CustomPieChart;