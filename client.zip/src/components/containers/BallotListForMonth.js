import React, { useEffect } from "react";
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

import { ballotsFetchData } from '../../actions/ballots';

const BallotListForMonth = (props) => { 
    useEffect(() => {
        props.fetchData(`http://localhost:5001/ballots/vuosi/${props.match.params.year}/kuukausi/${props.match.params.month}`);
    }, []);

    if (props.ballots.length === 0) {
        if (!props.isLoading) {
            return <div>no ballots for year {props.match.params.year}...</div>
        }
        return <div>loading...</div>;
    }

    return (
        <div style={{ backgroundColor: 'purple', textAlign: 'center' }}>
            {props.ballots.map((ballot) => (
                <div  style={{ border: 'solid black 1px', color: 'purple'}}>
                <Link style={{ underline: 'none', color: 'ghostwhite'}} to={`/ballots/${ballot.aanestysId}`}>
                    <h1>
                        {ballot.kohtaOtsikko + " " + ballot.aanestysOtsikko + " " + ballot.aanestysId}
                    </h1>
                </Link>
                </div>
            ))}
        </div>
    );
}

const mapStateToProps = (state) => {
    return {
        ballots: state.ballots,
        hasErrored: state.ballotsHasErrored,
        isLoading: state.ballotsIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url) => dispatch(ballotsFetchData(url))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BallotListForMonth);
