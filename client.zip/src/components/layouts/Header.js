import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Image } from 'react-bootstrap';

import "bootstrap/dist/css/bootstrap.min.css";

class Header extends Component {
    render() {
        return(
        <>
            <Image style={{ width:'10%', height:'10%' }} src={require(`./logo.PNG`)} />
            Big Sister
        </>);
    }
}

export default Header;