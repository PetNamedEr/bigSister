const cors = require('cors');
const express = require('express');
const ballotsRoute = require('./routes/ballots');
const routes = require('./routes/index');

let app = express();

app.use(cors());
app.options('*', cors());

app.use('/ballots', ballotsRoute);
app.use('/', routes);

app.listen(5001, () => console.log(`Listening on port ${5001}`));