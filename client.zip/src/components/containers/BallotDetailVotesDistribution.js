import React, { useState, useEffect } from "react";
import { connect } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import { ballotCandidateVotesFetchData } from '../../actions/ballotCandidateVotes';
import CustomPieChart from "./CustomPieChart";
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import {blueGrey, red, green, brown} from '@material-ui/core/colors';
import { Image } from 'react-bootstrap';

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    paper: {
        color: 'white',
      height: 180,
      width: 100,
    },
    control: {
      padding: theme.spacing(2),
    },
  }));

const BallotDetailVotesDistribution = (props) => {
    const classes = useStyles();

    const initPartyData = () => (
        {
            partyName: '',
            yes: 0,
            no: 0,
            away: 0,
            empty: 0,
        }
    )

    const makePartyData = (fetchedData) => {
        if (fetchedData.length === 0) {
            return [];
        }
        let newPartyData = [initPartyData(),initPartyData(),initPartyData(),initPartyData(),initPartyData(),initPartyData(),initPartyData(),initPartyData(),initPartyData()];

        fetchedData.data.forEach(partyData => {
            if (partyData.edustajaRyhmaLyhenne.includes('kd')) {
                console.log(partyData.edustajaAanestys + "kd");
                newPartyData[0].partyName = 'kd';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[0].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[0].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[0].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[0].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('kesk')) {
                newPartyData[1].partyName = 'kesk';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[1].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[1].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[1].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[1].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('kok')) {
                newPartyData[2].partyName = 'kok';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[2].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[2].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[2].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[2].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('liik')) {
                newPartyData[3].partyName = 'liik';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[3].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[3].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[3].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[3].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('ps')) {
                newPartyData[4].partyName = 'ps';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[4].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[4].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[4].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[4].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('r')) {
                newPartyData[5].partyName = 'r';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[5].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[5].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[5].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[5].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('sd')) {
                newPartyData[6].partyName = 'sd';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[6].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[6].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[6].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[6].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('vas')) {
                newPartyData[7].partyName = 'vas';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[7].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[7].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[7].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[7].no += 1;
                }

            }   
            if (partyData.edustajaRyhmaLyhenne.includes('vihr')) {
                newPartyData[8].partyName = 'vihr';
                if (partyData.edustajaAanestys.includes('Tyhjää')) {
                    newPartyData[8].empty += 1;
                } else if (partyData.edustajaAanestys.includes('Poissa')) {
                    newPartyData[8].away += 1;
                } else if (partyData.edustajaAanestys.includes('Jaa')) {
                    newPartyData[8].yes += 1;
                } else if (partyData.edustajaAanestys.includes('Ei')) {
                    newPartyData[8].no += 1;
                }
            }
        });

        return newPartyData;
    }

    useEffect(() => {
        props.fetchData(`http://localhost:5001/ballots/${props.aanestysId}/aanestysEdustajas`);
    }, []);

    const partyData = makePartyData(props.ballotCandidateVotes);
    const colors = [green[500], red[500], brown[500], blueGrey[500]];
    const getPieChartData = (d) => {
        return [
            {
                name: 'Yes',
                value: d.yes,
            },
            {
                name: 'No',
                value: d.no,
            },
            {
                name: 'Away',
                value: d.away,
            },
            {
                name: 'Empty',
                value: d.empty,
            },
        ];
    };

    const getBackgroundColorForParty = (partyData) => {
        if (partyData.yes > 0) {
            return 'limegreen';
        } else if (partyData.no > 0) {
            return 'firebrick';
        } else {
            return 'gray';
        }
    }

    if (props.ballotCandidateVotes.length === 0 || partyData === undefined) {
        return <div>loading candidates...</div>
    }
    return (
        <div>
            <Grid container className={classes.root} spacing={2}>
                <Grid item xs={12}>
                    <Grid container justify="center" spacing={3}>
                        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((value) => (
                        <Grid key={value} item>
                        <Paper className={classes.paper}
                            style={{ backgroundColor: getBackgroundColorForParty(partyData[value]) }}>
                            <Image style={{ width:'20%', height:'20%' }} className={classes.item} src={require(`./${props.partyList[value].name}.png`)} />
                            <br />
                            Yes: {partyData[value].yes} <br />
                            No: {partyData[value].no} <br />
                            Away: {partyData[value].away} <br />
                            Empty: {partyData[value].empty} <br />
                            <CustomPieChart pieChartData={getPieChartData(partyData[value])} canvasWidth={75} canvasHeight={75} colors={colors} />
                        </Paper>
                        </Grid>
                    ))}
                    </Grid>
                </Grid>
            </Grid>
        </div>
    );
}


const mapStateToProps = (state) => {
    return {
        ballotCandidateVotes: state.ballotCandidateVotes,
        hasErrored: state.ballotCandidateVotesHasErrored,
        isLoading: state.ballotCandidateVotesIsLoading
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        fetchData: (url) => dispatch(ballotCandidateVotesFetchData(url))
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BallotDetailVotesDistribution);
