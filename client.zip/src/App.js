import React, { Component } from 'react';
import './App.css';
import { Route, BrowserRouter } from 'react-router-dom';
import Home from './components/layouts/Home';
import Layout from './components/layouts/Layout';

import { Provider } from 'react-redux';

import configureStore from './store/configureStore';

import "bootstrap/dist/css/bootstrap.min.css";
import BallotList from './components/containers/BallotList';
import BallotCard from './components/containers/BallotCard';
import BallotListForYear from './components/containers/BallotListForYear';
import BallotListForMonth from './components/containers/BallotListForMonth';

const store = configureStore();

class App extends Component {
    render() {
        return (
            <Provider store={store} >
            <BrowserRouter>
                <Layout>
                    <Route exact path="/" component={Home} />
                    <Route exact path="/ballots/" component={BallotList} />
                    <Route exact path="/ballots/vuosi/:year" component={BallotListForYear} />
                    <Route exact path="/ballots/vuosi/:year/kuukausi/:month" component={BallotListForMonth} />
                    <Route exact path="/ballots/:id" component={BallotCard} />
                </Layout>
            </BrowserRouter>
            </Provider>
        );
    }
}

export default App;