import React, { useState, useEffect } from "react";
import { connect } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import { ballotsFetchData } from '../../actions/ballots';
import AdvancedGridList from "./AdvancedGridList";
import CustomPieChart from "./CustomPieChart";
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    paper: {
      height: 25,
      width: 100,
      color: 'white',
    },
    control: {
      padding: theme.spacing(2),
    },
  }));

const BallotDetailPartyList = (props) => {
  const classes = useStyles();
  
  return (
        <div>
            <Grid container className={classes.root} spacing={2}>
      <Grid item xs={12}>
        <Grid container justify="center" spacing={3}>
          {props.partyList.map((value) => (
            <Grid key={value.name} item>
              <Paper className={classes.paper} style={{ color: value.txtColor, backgroundColor: value.bgColor}}>
                {value.name}
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Grid>
    </Grid>
        </div>
    );
}

export default (BallotDetailPartyList);
