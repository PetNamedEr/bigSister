var mysql = require('mysql');

const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'django'
});

makeCallbackQuery = (sql, callback) => {
  pool.query({
    sql,
    timeout: 40000, // 40s
  }, function(error, results, fields) {
    if (error) throw error;
    callback(null, JSON.parse(JSON.stringify(results)));
  });
}

makeResQuery = (sql, req, res) => {
  pool.query({
    sql,
    timeout: 40000, // 40s
  }, function(error, results, fields) {
    if (error) throw error;
    //console.log(JSON.stringify(results));
    res.json({
      success: 1,
      data: JSON.parse(JSON.stringify(results))
    });
  });
}

module.exports = {
  makeResQuery,
  makeCallbackQuery,
};