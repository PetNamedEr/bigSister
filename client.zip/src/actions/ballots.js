export function ballotsHasErrored(bool) {
    return {
        type: 'BALLOTS_HAS_ERRORED',
        hasErrored: bool
    };
}export function ballotsIsLoading(bool) {
    return {
        type: 'BALLOTS_IS_LOADING',
        isLoading: bool
    };
}export function ballotsFetchDataSuccess(ballots) {
    return {
        type: 'BALLOTS_FETCH_DATA_SUCCESS',
        ballots
    };
}

export function ballotsFetchData(url) {
    return (dispatch) => {
        dispatch(ballotsIsLoading(true));     
            fetch(url)
            .then((response) => {
                if (!response.ok) {
                    throw Error(response.statusText);
                }                
                dispatch(ballotsIsLoading(false));                
                return response;
            })
            .then((response) => response.json())
            .then((ballots) => dispatch(ballotsFetchDataSuccess(ballots.data)))
            .catch(() => dispatch(ballotsHasErrored(true)));
    };
}