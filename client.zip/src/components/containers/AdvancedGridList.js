import React, { useState, useEffect } from "react";
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: 'gray',
    textAlign: 'center',
    color: 'black',
  },
}));

const defaultTileData = [
  {
    title: 'Tammikuu',
    howManyBallotsWereHeld: 0,
    monthNo: '01',
  },
  {
    title: 'Helmikuu',
    howManyBallotsWereHeld: 0,
    monthNo: '02',
  },
  {
    title: 'Maaliskuu',
    howManyBallotsWereHeld: 0,
    monthNo: '03',
  },
  {
    title: 'Huhtikuu',
    howManyBallotsWereHeld: 0,
    monthNo: '04',
  },
  {
    title: 'Toukokuu',
    howManyBallotsWereHeld: 0,
    monthNo: '05',
  },
  {
    title: 'Kesäkuu',
    howManyBallotsWereHeld: 0,
    monthNo: '06',
  },
  {
    title: 'Heinäkuu',
    howManyBallotsWereHeld: 0,
    monthNo: '07',
  },
  {
    title: 'Elokuu',
    howManyBallotsWereHeld: 0,
    monthNo: '08',
  },
  {
    title: 'Syyskuu',
    howManyBallotsWereHeld: 0,
    monthNo: '09',
  },
  {
    title: 'Lokakuu',
    howManyBallotsWereHeld: 0,
    monthNo: '10',
  },
  {
    title: 'Marraskuu',
    howManyBallotsWereHeld: 0,
    monthNo: '11',
  },
  {
    title: 'Joulukuu',
    howManyBallotsWereHeld: 0,
    monthNo: '12',
  },
];

const AdvancedGridList = (props) => {
  const classes = useStyles();

  const [sortingIsDone, setSortingIsDone] = useState(false);
  const [tileData, setTileData] = useState(defaultTileData);  

  const getMonthFromAanestysAlkuaika = (aanestysAlkuaika) => aanestysAlkuaika.split('-')[1];

  const getBallotsSortedByMonthArray = (ballots) => {
    if (ballots) {
      const newTileData = defaultTileData;

      ballots.map((ballot) => {
        switch (getMonthFromAanestysAlkuaika(ballot.aanestysAlkuaika)) {
          case '01':
            newTileData[0].howManyBallotsWereHeld += 1;
            break;
          case '02':
            newTileData[1].howManyBallotsWereHeld += 1;
            break;
          case '03':
            newTileData[2].howManyBallotsWereHeld += 1;
            break;
          case '04':
            newTileData[3].howManyBallotsWereHeld += 1;
            break;
          case '05':
            newTileData[4].howManyBallotsWereHeld += 1;
            break;
          case '06':
            newTileData[5].howManyBallotsWereHeld += 1;
            break;
          case '07':
            newTileData[6].howManyBallotsWereHeld += 1;
            break;
          case '08':
            newTileData[7].howManyBallotsWereHeld += 1;
            break;
          case '09':
            newTileData[8].howManyBallotsWereHeld += 1;
            break;
          case '10':
            newTileData[9].howManyBallotsWereHeld += 1;
            break;
          case '11':
            newTileData[10].howManyBallotsWereHeld += 1;
            break;
          case '12':
            newTileData[11].howManyBallotsWereHeld += 1;
            break;
        }
      });

      setTileData(newTileData);
      setSortingIsDone(true);
    }
  };

  const renderEmptyButton = (tile) => (
      <Button style={{ backgroundColor: 'ghostwhite' }} variant="outlined">
        {tile.title}<br />
        {tile.howManyBallotsWereHeld + " äänestystä"}
      </Button>
  );

  const renderLinkButtonToBallot = (tile) => (
    <Link to={`/ballots/vuosi/${props.year}/kuukausi/${tile.monthNo}`}>
      <Button style={{ backgroundColor: 'purple', color: 'white'}} variant="outlined">
        {tile.title}<br />
        {tile.howManyBallotsWereHeld + " äänestystä"}
      </Button>
    </Link>
  );

  useEffect(() => {
    getBallotsSortedByMonthArray(props.ballots);
  }, []);

  if (!sortingIsDone) {
    return <div>sorting...</div>;
  }

  if (props.ballots.length === 0) {
    return <div>no ballots for year!</div>
  }

  return (
    <div className={classes.root}>
      <br />
      <Grid container spacing={3}>
        {tileData.map((tile) => (
          <Grid item xs={6} sm={4}>
            <Paper className={classes.paper}>
              {tile.howManyBallotsWereHeld > 0 
                ? renderLinkButtonToBallot(tile)
                : renderEmptyButton(tile)}
            </Paper>
          </Grid>
        ))}
      </Grid>
    </div>
  );
}

export default AdvancedGridList;